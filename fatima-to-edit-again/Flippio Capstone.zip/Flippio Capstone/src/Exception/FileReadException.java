package Exception;

public class FileReadException extends Exception {
    public FileReadException(String message) { super(message); }
}
