# Upgrade Progress

  ### ❗ Generate Upgrade Plan [View Log](logs\1.generatePlan.log)
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  #### Errors
  - Failed to prepare project configuration or init upgrade options: Unsupported project type: undefined. only Maven, Maven Wrapper and Gradle Wrapper project is supported. Please choose a valid supported project. Please check the project configuration and try again.
  </details>