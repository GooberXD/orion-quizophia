package View;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;
import Utility.FontUtil;
import Utility.ResourceLoader;
import Model.Student;
import Model.Quiz;

public class TeacherDashboardView extends JFrame {
    private JLabel welcomeLabel;
    private JButton createQuizButton;
    private JButton deleteQuizButton;
    private JButton logoutButton;

    // Removed Student Performance table in favor of popup performance view

    private JTable rankTable;
    private DefaultTableModel rankModel;
    private JButton refreshRankBtn;
    private JButton backButton;
    private JLabel centerLogo;
    // Removed JList-based quiz list in favor of button panel
    private DefaultListModel<Student> studentListModel;
    private JList<Student> studentList;
    private JButton addStudentBtn;

    private JPanel quizButtonsPanel; // container for quiz buttons

    public TeacherDashboardView() {
        setTitle("Flippio - Teacher Dashboard");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);

        // Window Icon
        ImageIcon appIcon = ResourceLoader.loadImageIcon("Logo.png");
        if (appIcon == null) appIcon = ResourceLoader.loadImageIcon("Prototype Design.png");
        if (appIcon != null) setIconImage(appIcon.getImage());

        // 1. Top Panel
        JPanel topPanel = new JPanel(new GridBagLayout());
        topPanel.setBackground(Color.decode("#9146FF"));
        topPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        welcomeLabel = new JLabel("Hi, Teacher!");
        welcomeLabel.setFont(FontUtil.montserrat(20f, Font.BOLD, new Font("Arial", Font.BOLD, 20)));
        welcomeLabel.setForeground(Color.WHITE);
        backButton = new JButton("Back");
        backButton.setFont(FontUtil.montserrat(12f, Font.BOLD, new Font("Arial", Font.BOLD, 12)));
        logoutButton = new JButton("Logout");
        logoutButton.setFont(FontUtil.montserrat(12f, Font.BOLD, logoutButton.getFont()));
        logoutButton.setPreferredSize(new Dimension(100, 32));

        centerLogo = new JLabel();
        ImageIcon logoIcon = ResourceLoader.loadImageIcon("Prototype Design.png");
        if (logoIcon == null) logoIcon = ResourceLoader.loadImageIcon("Prototype Design.jpg");
        if (logoIcon != null) {
            Image scaled = logoIcon.getImage().getScaledInstance(200, 80, Image.SCALE_SMOOTH);
            centerLogo.setIcon(new ImageIcon(scaled));
        }
        centerLogo.setHorizontalAlignment(SwingConstants.CENTER);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridy = 0; gbc.insets = new Insets(0,0,0,0); gbc.fill = GridBagConstraints.NONE;

        // Left label
        gbc.gridx = 0; gbc.weightx = 0; gbc.anchor = GridBagConstraints.WEST;
        topPanel.add(welcomeLabel, gbc);
        // Center logo
        gbc.gridx = 1; gbc.weightx = 1; gbc.anchor = GridBagConstraints.CENTER;
        topPanel.add(centerLogo, gbc);
        // Right buttons
        JPanel rightButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        rightButtons.setOpaque(false);
        rightButtons.add(backButton);
        rightButtons.add(logoutButton);
        gbc.gridx = 2; gbc.weightx = 0; gbc.anchor = GridBagConstraints.EAST;
        topPanel.add(rightButtons, gbc);
        add(topPanel, BorderLayout.NORTH);

        // 2. Center Tabs
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(FontUtil.montserrat(12f, Font.PLAIN, tabbedPane.getFont()));

        // Removed Student Performance tab; performance now shown in quiz modal

        // Tab B: Manage Quizzes
        JPanel quizPanel = new JPanel(new BorderLayout());
        quizButtonsPanel = new JPanel();
        quizButtonsPanel.setLayout(new BoxLayout(quizButtonsPanel, BoxLayout.Y_AXIS));
        JScrollPane quizScroll = new JScrollPane(quizButtonsPanel);
        quizPanel.add(quizScroll, BorderLayout.CENTER);

        JPanel quizActions = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        createQuizButton = new JButton("Create New Quiz");
        createQuizButton.setFont(FontUtil.montserrat(14f, Font.BOLD, createQuizButton.getFont()));
        createQuizButton.setPreferredSize(new Dimension(200, 40));

        deleteQuizButton = new JButton("Delete a Quiz");
        deleteQuizButton.setFont(FontUtil.montserrat(14f, Font.BOLD, createQuizButton.getFont()));
        deleteQuizButton.setPreferredSize(new Dimension(200, 40));
        deleteQuizButton.setBackground(new Color(200, 50, 50));
        deleteQuizButton.setForeground(Color.WHITE);

        quizActions.add(createQuizButton);
        quizActions.add(deleteQuizButton);
        quizPanel.add(quizActions, BorderLayout.SOUTH);
        tabbedPane.addTab("Manage Quizzes", quizPanel);

        // Tab C: Ranking System
        JPanel rankingPanel = new JPanel(new BorderLayout());
        String[] rankCols = {"Rank", "Student Name", "Average Score"};
        rankModel = new DefaultTableModel(rankCols, 0);
        rankTable = new JTable(rankModel);
        rankTable.setFont(FontUtil.montserrat(12f, Font.PLAIN, rankTable.getFont()));
        rankTable.setRowHeight(22);
        rankTable.getTableHeader().setFont(FontUtil.montserrat(12f, Font.BOLD, rankTable.getTableHeader().getFont()));
        rankingPanel.add(new JScrollPane(rankTable), BorderLayout.CENTER);

        refreshRankBtn = new JButton("Calculate Rankings");
        refreshRankBtn.setFont(FontUtil.montserrat(12f, Font.BOLD, refreshRankBtn.getFont()));
        rankingPanel.add(refreshRankBtn, BorderLayout.SOUTH);

        tabbedPane.addTab("Ranking System", rankingPanel);

        // Tab D: Students
        JPanel studentsPanel = new JPanel(new BorderLayout());
        studentListModel = new DefaultListModel<>();
        studentList = new JList<>(studentListModel);
        studentList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        studentList.setFont(FontUtil.montserrat(12f, Font.PLAIN, studentList.getFont()));
        studentsPanel.add(new JScrollPane(studentList), BorderLayout.CENTER);
        addStudentBtn = new JButton("Add Student to Subject");
        addStudentBtn.setFont(FontUtil.montserrat(12f, Font.BOLD, addStudentBtn.getFont()));
        studentsPanel.add(addStudentBtn, BorderLayout.SOUTH);
        tabbedPane.addTab("Students", studentsPanel);

        add(tabbedPane, BorderLayout.CENTER);
        FontUtil.applyToTree(getContentPane(), FontUtil.montserrat(12f, Font.PLAIN, getFont()));
    }

    public void setTeacherName(String name) { welcomeLabel.setText("Hi, " + name + "!"); }
    // Quiz buttons management
    public void clearQuizButtons() {
        quizButtonsPanel.removeAll();
        quizButtonsPanel.revalidate();
        quizButtonsPanel.repaint();
    }
    public void addQuizButton(String quizName, ActionListener listener) {
        JButton btn = new JButton(quizName);
        btn.setAlignmentX(Component.LEFT_ALIGNMENT);
        btn.setFont(FontUtil.montserrat(12f, Font.BOLD, btn.getFont()));
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        btn.addActionListener(listener);
        quizButtonsPanel.add(btn);
        quizButtonsPanel.add(Box.createVerticalStrut(6));
        quizButtonsPanel.revalidate();
        quizButtonsPanel.repaint();
    }

    public void addRankingRow(int rank, String name, double avg) {
        rankModel.addRow(new Object[]{rank, name, String.format("%.2f", avg)});
    }
    public void clearRankings() { rankModel.setRowCount(0); }

    public void addRefreshRankListener(ActionListener listener) { refreshRankBtn.addActionListener(listener); }
    public void addLogoutListener(ActionListener listener) { logoutButton.addActionListener(listener); }
    public void addCreateQuizListener(ActionListener listener) { createQuizButton.addActionListener(listener); }
    public void addDeleteQuizListener(ActionListener listener) { deleteQuizButton.addActionListener(listener); }
    public void addBackListener(ActionListener listener) { backButton.addActionListener(listener); }
        public void setQuizList(java.util.List<String> names) {
            clearQuizButtons();
            for (String n : names) { addQuizButton(n, e -> {}); }
        }
    public void setStudents(List<Student> students) {
        studentListModel.clear();
        for (Student s : students) studentListModel.addElement(s);
    }

    public void addAddStudentToSubjectListener(ActionListener listener) { addStudentBtn.addActionListener(listener); }
}