package Exception;

public class DuplicateQuizException extends Exception {
    public DuplicateQuizException(String message) { super(message); }
}
