package Controller;

import Model.*;
import View.*;
import Service.*;
import FileManager.*;
import Exception.*; // Custom Exceptions
import java.awt.Dimension;
import java.util.*;
import javax.swing.*;
import FileManager.SubjectMembershipFileManager;

public class StudentDashboardController {
    private StudentDashboardView view;
    private Student student;

    public StudentDashboardController(StudentDashboardView view, Student student) {
        this.view = view;
        this.student = student;

        initDashboard();
    }

    private void initDashboard() {
        view.setStudentName(student.getName());
        loadPerformanceData();
        loadQuizButtons();
        view.addLogoutListener(e -> logout());
        view.addDownloadListener(e -> downloadReport());
    }

    private void loadPerformanceData() {
        // Prefer authoritative data from scores.csv; fallback to in-memory results
        double percentageSum = 0.0;
        int entries = 0;

        try {
            ScoreService scoreService = new ScoreService("scores.csv");
            java.util.List<QuizResult> all = scoreService.getAllResults();

            for (QuizResult r : all) {
                if (student.getIdNumber().equals(r.getStudentId())) {
                    double percent = (r.getTotalItems() == 0) ? 0.0 : (r.getScore() / r.getTotalItems()) * 100.0;
                    String status = (percent >= 50.0) ? "PASSED" : "FAILED";
                    view.addResultRow(r.getQuizName(), r.getScore(), (double) r.getTotalItems(), status);
                    percentageSum += percent;
                    entries++;
                }
            }
        } catch (Exception ex) {
            // Ignore and fallback below
        }

        if (entries == 0) {
            // Fallback to in-memory results if no CSV entries yet
            java.util.List<Double> results = student.getQuizResults();
            int count = 1;
            for (Double score : results) {
                String quizName = "Quiz Attempt " + count;
                // Assume 10 items default for legacy results to estimate %
                double percent = (score / 10.0) * 100.0;
                String status = (percent >= 50.0) ? "PASSED" : "FAILED";
                view.addResultRow(quizName, score, 10.0, status);
                percentageSum += percent;
                entries++;
                count++;
            }
        }

        double averagePercent = (entries == 0) ? 0.0 : (percentageSum / entries);
        view.updateAverageScore(averagePercent);
    }

    private void loadQuizButtons() {
        view.clearQuizButtons();
        QuizFileManager quizManager = new QuizFileManager("quizzes.txt");
        List<Quiz> availableQuizzes = new ArrayList<>();

        try {
            availableQuizzes = quizManager.load();
        } catch (Exception e) {
            System.err.println("Could not load quizzes: " + e.getMessage());
        }

        // Show only quizzes that are published by teachers AND belong to subjects the student is enrolled in
        java.util.List<Quiz> visibleQuizzes = new java.util.ArrayList<>();
        // Build enrolled subject set
        java.util.Set<String> enrolledSubjectIds = new java.util.HashSet<>();
        try {
            // If teacher-managed subjects exist, membership files are named subject_<subjectId>.csv
            // We'll scan quizzes to know candidate subject IDs, then check membership files
            java.util.Set<String> candidateSubjectIds = new java.util.HashSet<>();
            for (Quiz q : availableQuizzes) {
                if (q != null && q.getSubjectId() != null && !q.getSubjectId().isEmpty()) {
                    candidateSubjectIds.add(q.getSubjectId());
                }
            }
            for (String sid : candidateSubjectIds) {
                try {
                    SubjectMembershipFileManager sm = new SubjectMembershipFileManager(sid);
                    java.util.List<String> members = sm.loadStudentIds();
                    if (members.stream().anyMatch(id -> id.equals(student.getIdNumber()))) {
                        enrolledSubjectIds.add(sid);
                    }
                } catch (Exception ignore) {}
            }
        } catch (Exception ignore) {}

        for (Quiz q : availableQuizzes) {
            if (q != null && q.isPublished()) {
                String sid = q.getSubjectId();
                // If quiz has a subjectId, require enrollment; if not, include for backward compatibility
                if (sid == null || sid.isEmpty() || enrolledSubjectIds.contains(sid)) {
                    visibleQuizzes.add(q);
                }
            }
        }

        if (!visibleQuizzes.isEmpty()) {
            for (Quiz q : visibleQuizzes) {
                view.addQuizButton(q.getQuizName(), e -> launchQuiz(q));
            }
            return;
        }

        // Fallback: add built-in default topics when no quizzes are available from file
        addDefaultTopicButton("Fundamentals of OOP");
        addDefaultTopicButton("Abstract Classes");
        addDefaultTopicButton("Polymorphism");
    }

    private void launchQuiz(Quiz quiz) {
        QuizTakingView quizView = new QuizTakingView();
        new QuizTakingController(quizView, quiz, student);
        view.dispose();
        quizView.setVisible(true);
    }

    // Helpers for default topic fallback (from earlier implementation)
    private void addDefaultTopicButton(String topic) {
        view.addQuizButton(topic, e -> launchDefaultTopic(topic));
    }

    private void launchDefaultTopic(String topic) {
        Quiz quiz = buildDefaultQuizFor(topic);
        launchQuiz(quiz);
    }

    private Quiz buildDefaultQuizFor(String topic) {
        Quiz quiz = new Quiz(topic);
        List<String> options = Arrays.asList("A", "B", "C", "D");

        quiz.addQuestion(new Question("Sample Question 1 for " + topic, options, 0));
        quiz.addQuestion(new Question("Sample Question 2 for " + topic, options, 1));
        quiz.addQuestion(new Question("Sample Question 3 for " + topic, options, 2));
        quiz.addQuestion(new Question("Sample Question 4 for " + topic, options, 3));
        quiz.addQuestion(new Question("Sample Question 5 for " + topic, options, 0));
        quiz.addQuestion(new Question("Sample Question 6 for " + topic, options, 1));
        quiz.addQuestion(new Question("Sample Question 7 for " + topic, options, 2));
        quiz.addQuestion(new Question("Sample Question 8 for " + topic, options, 3));
        quiz.addQuestion(new Question("Sample Question 9 for " + topic, options, 0));
        quiz.addQuestion(new Question("Sample Question 10 for " + topic, options, 1));

        return quiz;
    }

    // --- MODIFIED METHOD: DOWNLOAD AND DISPLAY ---
    private void downloadReport() {
        // 1. Build the Report Content in Memory (from CSV if available)
        StringBuilder reportBuilder = new StringBuilder();

        java.util.List<QuizResult> myResults = new java.util.ArrayList<>();
        try {
            ScoreService scoreService = new ScoreService("scores.csv");
            for (QuizResult r : scoreService.getAllResults()) {
                if (student.getIdNumber().equals(r.getStudentId())) {
                    myResults.add(r);
                }
            }
        } catch (Exception ignore) { }

        double avgPercent;
        if (!myResults.isEmpty()) {
            double sum = 0.0;
            for (QuizResult r : myResults) {
                sum += (r.getTotalItems() == 0) ? 0.0 : (r.getScore() / r.getTotalItems()) * 100.0;
            }
            avgPercent = sum / myResults.size();
        } else {
            // fallback using in-memory average with assumed 10 items
            java.util.List<Double> results = student.getQuizResults();
            if (results.isEmpty()) {
                avgPercent = 0.0;
            } else {
                double sum = 0.0;
                for (Double s : results) sum += (s / 10.0) * 100.0;
                avgPercent = sum / results.size();
            }
        }

        reportBuilder.append("FLIPPIO STUDENT REPORT\n");
        reportBuilder.append("----------------------\n");
        reportBuilder.append("Student: ").append(student.getName()).append("\n");
        reportBuilder.append("ID: ").append(student.getIdNumber()).append("\n");
        reportBuilder.append("Average Performance: ").append(String.format("%.2f%%", avgPercent)).append("\n");
        reportBuilder.append("----------------------\n");
        reportBuilder.append("Quiz History:\n");

        if (!myResults.isEmpty()) {
            for (QuizResult r : myResults) {
                double percent = (r.getTotalItems() == 0) ? 0.0 : (r.getScore() / r.getTotalItems()) * 100.0;
                String status = (percent >= 50.0) ? "PASSED" : "FAILED";
                reportBuilder
                    .append("- Quiz: ").append(r.getQuizName())
                    .append(" | Score: ").append(String.format("%.0f", r.getScore()))
                    .append(" / ").append(r.getTotalItems())
                    .append(" (").append(String.format("%.2f%%", percent)).append(")")
                    .append(" | Status: ").append(status)
                    .append("\n");
            }
        } else {
            java.util.List<Double> results = student.getQuizResults();
            int count = 1;
            for (Double s : results) {
                double percent = (s / 10.0) * 100.0; // assume 10 items legacy
                String status = (percent >= 50.0) ? "PASSED" : "FAILED";
                reportBuilder
                    .append("- Quiz Attempt ").append(count)
                    .append(" | Score: ").append(String.format("%.0f", s))
                    .append(" / 10 (").append(String.format("%.2f%%", percent)).append(")")
                    .append(" | Status: ").append(status)
                    .append("\n");
                count++;
            }
        }

        String reportContent = reportBuilder.toString();
        String fileName = "Report_" + student.getName().replaceAll(" ", "_") + ".txt";

        // 2. Save to File
        try (java.io.BufferedWriter writer = new java.io.BufferedWriter(new java.io.FileWriter(fileName))) {
            writer.write(reportContent);

            // Success Message
            JOptionPane.showMessageDialog(view, "Report downloaded successfully to: " + fileName);

            // 3. SHOW DIALOG (GUI Output)
            showReportDialog(reportContent);

        } catch (java.io.IOException e) {
            // Throw Custom Exception
            JOptionPane.showMessageDialog(view, new FileWriteException("Could not save report: " + e.getMessage()).getMessage());
        }
    }

    // Helper to show the report in a scrollable text area
    private void showReportDialog(String content) {
        JTextArea textArea = new JTextArea(content);
        textArea.setEditable(false);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setFont(new java.awt.Font("Monospaced", java.awt.Font.PLAIN, 13));

        // Add vertical padding at both ends of content
        textArea.setBorder(javax.swing.BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JScrollPane scrollPane = new JScrollPane(textArea);
        // Increase width so PASS/FAILED stays on one line
        scrollPane.setPreferredSize(new Dimension(600, 450));

        JOptionPane.showMessageDialog(view, scrollPane, "Grade Report Preview", JOptionPane.INFORMATION_MESSAGE);
    }

    private void logout() {
        view.dispose();
        LoginView loginView = new LoginView();
        AuthService auth = AuthService.getInstance();
        new LoginController(loginView, auth);
        loginView.setVisible(true);
    }
}