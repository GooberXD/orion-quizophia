package Controller;

import View.*;
import Model.*;
import Service.*;
import Exception.*; // Import custom exceptions

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class LoginController {
    private LoginView view;
    private AuthService authService;

    public LoginController(LoginView view, AuthService authService) {
        this.view = view;
        this.authService = authService;

        // 1. Attach Login Listener
        this.view.addLoginListener(e -> performLogin());

        // 2. Attach Signup Listener
        this.view.addSignupListener(e -> performSignup());
    }

    // --- LOGIN LOGIC ---
    private void performLogin() {
        try {
            String id = view.getIdInput();
            String pass = view.getPassInput();

            if(id.isEmpty() || pass.isEmpty()) {
                view.showErrorMessage("Please fill in all login fields.");
                return;
            }

            User user = authService.login(id, pass);

            if (user instanceof Student) {
                view.dispose();
                openStudentDashboard((Student) user);
            } else if (user instanceof Teacher) {
                view.dispose();
                openTeacherDashboard((Teacher) user);
            }

        } catch (Exception ex) {
            view.showErrorMessage("Login Failed: " + ex.getMessage());
        }
    }

    // --- SIGNUP LOGIC ---
    private void performSignup() {
        try {
            // 1. Get Data from View
            String name = view.getSignName();
            String id = view.getSignId();
            String role = view.getSignRole();
            String pass = view.getSignPass();

            // 2. Input Validation
            if (name.isEmpty() || id.isEmpty() || role.isEmpty() || pass.isEmpty()) {
                view.showErrorMessage("Please fill in all registration fields.");
                return;
            }

            // 3. Call Service to Register
            // Note: The Service handles checking for duplicates and saving to file
            authService.register(id, pass, name, role.trim());

            // 4a. Allocate per-user CSVs
            try {
                if ("Student".equalsIgnoreCase(role.trim())) {
                    FileManager.StudentPerformanceFileManager spfm = new FileManager.StudentPerformanceFileManager(id);
                    spfm.ensureExists();
                } else if ("Teacher".equalsIgnoreCase(role.trim())) {
                    // Create teacher CSVs: subject_<id>.csv, quiz_<id>.csv and membership_<id>.csv folder/file
                    FileManager.TeacherSubjectSummaryFileManager tss = new FileManager.TeacherSubjectSummaryFileManager(id);
                    tss.writeAll(new java.util.ArrayList<>()); // initialize empty
                    FileManager.TeacherQuizSummaryFileManager tqs = new FileManager.TeacherQuizSummaryFileManager(id);
                    tqs.writeAll(new java.util.ArrayList<>()); // initialize empty
                    // Subject membership per teacher is already managed by SubjectMembershipFileManager per subject id
                }
            } catch (Exception ignore) { /* allocation best-effort */ }

            // 4. Success Feedback
            JOptionPane.showMessageDialog(view, "Account successfully created!");

            // Reset form and return to landing panel
            view.resetSignupFormAndReturnToLanding();

        } catch (UserInputErrorException ex) {
            // Logic Error (Duplicate ID, Invalid Role)
            view.showErrorMessage(ex.getMessage());
        } catch (Exception ex) {
            // System Error (File IO)
            view.showErrorMessage("System Error: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    // Helper: Opens the Student Dashboard
    private void openStudentDashboard(Student student) throws IOException, FontFormatException {
        // Ensure per-student performance CSV exists even for pre-existing accounts
        try {
            FileManager.StudentPerformanceFileManager spfm = new FileManager.StudentPerformanceFileManager(student.getIdNumber());
            spfm.ensureExists();
        } catch (Exception ignore) { /* best-effort; dashboard should still open */ }
        StudentDashboardView dashboardView = new StudentDashboardView();
        new StudentDashboardController(dashboardView, student);
        dashboardView.setVisible(true);
    }

    // Helper: Opens the Teacher Dashboard
    private void openTeacherDashboard(Teacher teacher) {
        View.TeacherSubjectDashboardView view = new View.TeacherSubjectDashboardView();
        String perUserSubjects = "subject_" + teacher.getIdNumber() + ".csv";
        FileManager.SubjectFileManager sfm = new FileManager.SubjectFileManager(perUserSubjects);
        new Controller.SubjectController(sfm, view, teacher);
        view.setVisible(true);
    }
}