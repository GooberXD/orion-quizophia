package FileManager;

import Model.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class QuizFileManager {
    private String fileName;

    public QuizFileManager(String fileName) {
        this.fileName = fileName;
    }

    // EXISTING SAVE (Appends one quiz)
    public void save(Quiz quiz) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true))) {
            writeQuizToBuffer(writer, quiz);
        }
    }

    // --- NEW METHOD: DELETE QUIZ ---
    public void deleteQuiz(String quizName) throws Exception {
        // 1. Load all existing quizzes
        List<Quiz> allQuizzes = load();

        // 2. Remove the one matching the name
        boolean removed = allQuizzes.removeIf(q -> q.getQuizName().equalsIgnoreCase(quizName));

        if (!removed) {
            throw new Exception("Quiz '" + quizName + "' not found.");
        }

        // 3. Overwrite the file with the remaining quizzes
        saveAll(allQuizzes);
    }

    // --- HELPER: OVERWRITE FILE ---
    private void saveAll(List<Quiz> quizzes) throws IOException {
        // "false" in FileWriter means overwrite, not append
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, false))) {
            for (Quiz q : quizzes) {
                writeQuizToBuffer(writer, q);
            }
        }
    }

    // --- HELPER: FORMATTING LOGIC ---
    // Extracted this logic so it can be used by both save() and saveAll()
    private void writeQuizToBuffer(BufferedWriter writer, Quiz quiz) throws IOException {
        writer.write("QUIZ|" + quiz.getQuizName());
        writer.newLine();
        // Optional metadata line for teacher and subject
        {
            String t = quiz.getTeacherId() == null ? "" : quiz.getTeacherId();
            String s = quiz.getSubjectId() == null ? "" : quiz.getSubjectId();
            String p = Boolean.toString(quiz.isPublished());
            writer.write("META|" + t + "|" + s + "|" + p);
            writer.newLine();
        }

        for (Question q : quiz.getQuestions()) {
            StringBuilder sb = new StringBuilder();
            sb.append("Q|").append(q.getQuestionText()).append("|");

            for (String choice : q.getChoices()) {
                sb.append(choice).append("|");
            }

            sb.append(q.getCorrectAnswerIndex());

            writer.write(sb.toString());
            writer.newLine();
        }
        writer.write("END_QUIZ");
        writer.newLine();
    }

    // EXISTING LOAD METHOD (Unchanged)
    public List<Quiz> load() throws IOException {
        List<Quiz> quizzes = new ArrayList<>();
        File file = new File(fileName);
        if (!file.exists()) return quizzes;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            Quiz currentQuiz = null;
            boolean expectingMeta = false;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");

                if (line.startsWith("QUIZ|")) {
                    currentQuiz = new Quiz(parts[1]);
                    expectingMeta = true; // next line may be META or Q
                } else if (expectingMeta && line.startsWith("META|") && currentQuiz != null) {
                    String teacherId = parts.length > 1 ? parts[1] : "";
                    String subjectId = parts.length > 2 ? parts[2] : "";
                    String published = parts.length > 3 ? parts[3] : "false";
                    currentQuiz.setTeacherId(teacherId.isEmpty() ? null : teacherId);
                    currentQuiz.setSubjectId(subjectId.isEmpty() ? null : subjectId);
                    currentQuiz.setPublished(Boolean.parseBoolean(published));
                    expectingMeta = false;
                } else if (line.startsWith("Q|") && currentQuiz != null) {
                    expectingMeta = false; // metadata absent
                    String text = parts[1];
                    List<String> choices = new ArrayList<>();
                    choices.add(parts[2]);
                    choices.add(parts[3]);
                    choices.add(parts[4]);
                    choices.add(parts[5]);
                    int correctIndex = Integer.parseInt(parts[6]);

                    currentQuiz.addQuestion(new Question(text, choices, correctIndex));
                } else if (line.equals("END_QUIZ")) {
                    if (currentQuiz != null) {
                        quizzes.add(currentQuiz);
                        currentQuiz = null;
                        expectingMeta = false;
                    }
                }
            }
        }
        return quizzes;
    }

    // Update an existing quiz by name
    public void updateQuiz(Quiz updated) throws IOException, Exception {
        List<Quiz> all = load();
        boolean found = false;
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).getQuizName().equalsIgnoreCase(updated.getQuizName())) {
                all.set(i, updated);
                found = true;
                break;
            }
        }
        if (!found) throw new Exception("Quiz '" + updated.getQuizName() + "' not found to update.");
        saveAll(all);
    }

    // Mark a quiz as published
    public void publishQuiz(String quizName) throws IOException, Exception {
        List<Quiz> all = load();
        boolean found = false;
        for (Quiz q : all) {
            if (q.getQuizName().equalsIgnoreCase(quizName)) {
                q.setPublished(true);
                found = true;
                break;
            }
        }
        if (!found) throw new Exception("Quiz '" + quizName + "' not found to publish.");
        saveAll(all);
    }
}