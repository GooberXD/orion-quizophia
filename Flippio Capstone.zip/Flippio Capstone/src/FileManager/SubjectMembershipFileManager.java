package FileManager;

import Exception.FileReadException;
import Exception.FileWriteException;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Stores student IDs for a given subject in a file named `subject_<subjectId>.csv`.
 */
public class SubjectMembershipFileManager {
    private final File file;

    public SubjectMembershipFileManager(String subjectId) {
        this.file = new File("subject_" + subjectId + ".csv");
    }

    public List<String> loadStudentIds() throws FileReadException {
        List<String> ids = new ArrayList<>();
        if (!file.exists()) return ids;
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) ids.add(line);
            }
            return ids;
        } catch (IOException e) {
            throw new FileReadException("Failed to read subject membership: " + file.getAbsolutePath());
        }
    }

    public void addStudentId(String studentId) throws FileWriteException, FileReadException {
        Set<String> ids = new HashSet<>(loadStudentIds());
        if (studentId != null && !studentId.trim().isEmpty()) {
            ids.add(studentId.trim());
        }
        overwrite(new ArrayList<>(ids));
    }

    public void removeStudentId(String studentId) throws FileWriteException, FileReadException {
        List<String> ids = loadStudentIds();
        ids.removeIf(id -> id.equals(studentId));
        overwrite(ids);
    }

    private void overwrite(List<String> ids) throws FileWriteException {
        try {
            File parent = file.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();
            try (BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file, false), StandardCharsets.UTF_8))) {
                for (String id : ids) {
                    bw.write(id);
                    bw.newLine();
                }
            }
        } catch (IOException e) {
            throw new FileWriteException("Failed to write subject membership: " + file.getAbsolutePath());
        }
    }
}
