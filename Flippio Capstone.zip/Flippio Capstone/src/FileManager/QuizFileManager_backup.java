// Backup before modification
