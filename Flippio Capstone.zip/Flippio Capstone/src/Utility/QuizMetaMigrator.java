package Utility;

import FileManager.QuizFileManager;
import Model.Quiz;
import java.util.*;

public final class QuizMetaMigrator {
    private QuizMetaMigrator() {}

    /**
     * Migrates quizzes.txt to include META lines for teacherId/subjectId.
     * Any quiz missing metadata will be tagged with provided teacherId/subjectId.
     */
    public static void migrate(String teacherId, String subjectId) throws Exception {
        QuizFileManager qfm = new QuizFileManager("quizzes.txt");
        List<Quiz> quizzes = qfm.load();
        for (Quiz q : quizzes) {
            if (q.getTeacherId() == null && teacherId != null) q.setTeacherId(teacherId);
            if (q.getSubjectId() == null && subjectId != null) q.setSubjectId(subjectId);
        }
        // Overwrite by saving all
        java.io.BufferedWriter bw = new java.io.BufferedWriter(new java.io.FileWriter("quizzes.txt", false));
        for (Quiz q : quizzes) {
            // Reuse formatting via FileManager by instantiating a fresh manager per quiz
            // Using internal write sequence: QUIZ, META (optional), Q..., END_QUIZ
            bw.write("QUIZ|" + q.getQuizName());
            bw.newLine();
            String t = q.getTeacherId() == null ? "" : q.getTeacherId();
            String s = q.getSubjectId() == null ? "" : q.getSubjectId();
            if (!t.isEmpty() || !s.isEmpty()) {
                bw.write("META|" + t + "|" + s);
                bw.newLine();
            }
            for (Model.Question ques : q.getQuestions()) {
                StringBuilder sb = new StringBuilder();
                sb.append("Q|").append(ques.getQuestionText()).append("|");
                for (String choice : ques.getChoices()) sb.append(choice).append("|");
                sb.append(ques.getCorrectAnswerIndex());
                bw.write(sb.toString());
                bw.newLine();
            }
            bw.write("END_QUIZ");
            bw.newLine();
        }
        bw.close();
    }
}
